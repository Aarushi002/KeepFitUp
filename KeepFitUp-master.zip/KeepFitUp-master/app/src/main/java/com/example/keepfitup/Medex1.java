package com.example.keepfitup;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class Medex1 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_medex1);
    }
}